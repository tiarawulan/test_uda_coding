package com.example.uda_coding_rumah_sakit

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
